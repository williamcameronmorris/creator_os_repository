import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { TrendingUp, ArrowUp, ArrowDown, Lightbulb, CheckCircle2, Save } from 'lucide-react';

interface AnalysisStageProps {
  workflowId: string;
  onComplete: () => void;
}

export function AnalysisStage({ workflowId, onComplete }: AnalysisStageProps) {
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState({
    views: 0,
    likes: 0,
    comments: 0,
    engagementRate: 0,
    avgViews: 1200
  });
  const [insight, setInsight] = useState('');
  const [nextIdea, setNextIdea] = useState('');

  useEffect(() => {
    loadData();
  }, [workflowId]);

  const loadData = async () => {
    setLoading(true);
    const { data: workflow } = await supabase
      .from('content_workflow_stages')
      .select('published_post_id, analysis_notes')
      .eq('id', workflowId)
      .maybeSingle();

    if (workflow?.published_post_id) {
      const simulatedViews = Math.floor(Math.random() * 5000) + 500;
      const simulatedLikes = Math.floor(simulatedViews * 0.1);

      setMetrics({
        views: simulatedViews,
        likes: simulatedLikes,
        comments: Math.floor(simulatedLikes * 0.05),
        engagementRate: ((simulatedLikes / simulatedViews) * 100),
        avgViews: 1500
      });

      if (workflow.analysis_notes) {
        setInsight(workflow.analysis_notes.key_learning || '');
        setNextIdea(workflow.analysis_notes.next_idea || '');
      }
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!insight) return;
    setLoading(true);

    await supabase
      .from('content_workflow_stages')
      .update({
        status: 'completed',
        current_stage: 'completed',
        analysis_notes: {
          key_learning: insight,
          next_idea: nextIdea,
          final_metrics: metrics
        },
        updated_at: new Date().toISOString()
      })
      .eq('id', workflowId);

    if (nextIdea) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('saved_content_ideas').insert({
          user_id: user.id,
          title: nextIdea,
          platform: 'instagram',
          content_type: 'reel',
          notes: `Inspired by insight: ${insight}`,
          inspiration_source: 'Analytics Retro'
        });
      }
    }

    onComplete();
    setLoading(false);
  };

  const performanceColor = metrics.views >= metrics.avgViews ? 'text-emerald-600' : 'text-amber-600';
  const performanceIcon = metrics.views >= metrics.avgViews ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-10">
        <h2 className="text-2xl font-bold text-slate-900">The Retro</h2>
        <p className="text-slate-500 text-sm mt-1">
          Review performance and capture one key learning to improve your next video.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Views</p>
          <div className="flex items-center justify-center gap-2">
            <span className="text-3xl font-bold text-slate-900">{metrics.views.toLocaleString()}</span>
            <div className={`flex items-center text-xs font-bold ${performanceColor} bg-slate-50 px-2 py-1 rounded-lg`}>
              {performanceIcon}
              {Math.abs(Math.round(((metrics.views - metrics.avgViews) / metrics.avgViews) * 100))}%
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-2">vs. your average ({metrics.avgViews})</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Engagement</p>
          <div className="text-3xl font-bold text-slate-900">{metrics.engagementRate.toFixed(1)}%</div>
          <p className="text-xs text-slate-400 mt-2">{metrics.likes} likes • {metrics.comments} comments</p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-center flex flex-col items-center justify-center">
          <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center mb-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          <p className="text-sm font-medium text-slate-600">
            {metrics.views > metrics.avgViews ? "This outperformed!" : "Room to improve."}
          </p>
        </div>
      </div>

      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-8">
        <div className="flex items-start gap-4 mb-6">
          <div className="p-3 bg-yellow-100 rounded-xl text-yellow-700">
            <Lightbulb className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">What did we learn?</h3>
            <p className="text-slate-500 text-sm">
              Don't just look at numbers. Why did this perform the way it did?
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Key Takeaway (The "Insight")
            </label>
            <textarea
              value={insight}
              onChange={(e) => setInsight(e.target.value)}
              placeholder="e.g. The text overlay hook worked better than just talking..."
              className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none bg-white min-h-[100px]"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Next Video Idea (Optional)
            </label>
            <input
              type="text"
              value={nextIdea}
              onChange={(e) => setNextIdea(e.target.value)}
              placeholder="e.g. Try the same hook format on a different topic..."
              className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            />
            <p className="text-xs text-slate-400 mt-2 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              This will automatically be added to your Saved Ideas.
            </p>
          </div>

          <div className="pt-4 flex justify-end">
            <button
              onClick={handleSave}
              disabled={loading || !insight}
              className="px-8 py-3 bg-slate-900 text-white rounded-xl font-medium hover:bg-slate-800 transition-all shadow-lg flex items-center gap-2 disabled:opacity-50"
            >
              {loading ? 'Saving...' : 'Complete Workflow'}
              <Save className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
