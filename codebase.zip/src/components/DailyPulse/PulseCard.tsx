import { useState, ReactNode } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

export type CardCategory = 'content' | 'engagement' | 'schedule' | 'tips';

interface PulseCardProps {
  category: CardCategory;
  categoryLabel: string;
  title: string;
  metric: string | number;
  metricLabel: string;
  badges?: { label: string; variant: 'default' | 'success' | 'warning' | 'danger' }[];
  children: ReactNode;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const categoryStyles: Record<CardCategory, { bg: string; accent: string; label: string }> = {
  content: {
    bg: 'bg-sky-50',
    accent: 'text-sky-600',
    label: 'WEEKLY REVIEW',
  },
  engagement: {
    bg: 'bg-teal-50',
    accent: 'text-teal-600',
    label: 'ENGAGEMENT',
  },
  schedule: {
    bg: 'bg-rose-50',
    accent: 'text-rose-600',
    label: 'SCHEDULE',
  },
  tips: {
    bg: 'bg-emerald-50',
    accent: 'text-emerald-600',
    label: 'AI INSIGHTS',
  },
};

const badgeVariants = {
  default: 'bg-gray-100 text-gray-700',
  success: 'bg-emerald-100 text-emerald-700',
  warning: 'bg-amber-100 text-amber-700',
  danger: 'bg-red-100 text-red-700',
};

export function PulseCard({
  category,
  categoryLabel,
  title,
  metric,
  metricLabel,
  badges = [],
  children,
  isExpanded,
  onToggleExpand,
}: PulseCardProps) {
  const styles = categoryStyles[category];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden transition-all duration-300">
      <div className={`${styles.bg} px-5 pt-4 pb-3 border-b border-gray-100`}>
        <p className={`text-xs font-semibold tracking-wider ${styles.accent} opacity-80 mb-1`}>
          {categoryLabel || styles.label}
        </p>
        <h3 className="text-xl font-bold text-gray-900">{title}</h3>
      </div>

      <div className="p-5">
        <div className="mb-4">
          <p className="text-3xl font-bold text-gray-900">{metric}</p>
          <p className="text-sm text-gray-500">{metricLabel}</p>
        </div>

        {badges.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {badges.map((badge, index) => (
              <span
                key={index}
                className={`px-2.5 py-1 rounded-full text-xs font-medium ${badgeVariants[badge.variant]}`}
              >
                {badge.label}
              </span>
            ))}
          </div>
        )}

        <button
          onClick={onToggleExpand}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors"
        >
          {isExpanded ? 'Collapse' : 'Expand'}
          {isExpanded ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </button>

        <div
          className={`overflow-hidden transition-all duration-300 ease-in-out ${
            isExpanded ? 'max-h-[2000px] opacity-100 mt-4' : 'max-h-0 opacity-0'
          }`}
        >
          <div className="border-t border-gray-100 pt-4">{children}</div>
        </div>
      </div>
    </div>
  );
}
